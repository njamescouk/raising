# rpal

Following on from [pbmGetProfile](https://github.com/njamescouk/pbmGetProfile), given a table of values 
of (radius, height), rpal will produce a visualisation of the theoretical wall thickness. 

See [raising.pdf](https://github.com/njamescouk/rpal/blob/master/doc/raising.pdf) for further details.

The file list here is inadequate. If you're having problems running or building this 
software download the 
 [zip file](https://github.com/njamescouk/rpal/releases/download/v1.0/rpal_1.0.zip), 
 which contains binaries needed for windows.

